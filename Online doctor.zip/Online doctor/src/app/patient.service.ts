import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class PatientService {
   baseUrl = 'http://localhost:5000/api/patient';
  constructor(private _http: HttpClient) { }

  register(patient) {
    return this._http.post(this.baseUrl, patient);
    // localStorage.setItem('user', user);
  }
}

