export interface Patient {
  firstname?: string;
  lastname: string,
    age : number
    mobileNo: number,
    gender :string,
    pin :number,
    email: string;
    password: string;
  }