import { Component, OnInit } from '@angular/core';
import { Patient } from '../Models/Patient';
import { PatientService } from '../patient.service';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-patient-register',
  templateUrl: './patient-register.component.html',
  styleUrls: ['./patient-register.component.css']
})
export class PatientRegisterComponent implements OnInit {

  patient: Patient = {
    firstname: '',
    lastname: '',
    age : 0,
    mobileNo: 0,
    gender :'',
    pin :0,
    email: '',
    password: ''
  };

  form: FormGroup = new FormGroup({});

  constructor(private service: PatientService) { 
  }
  registered = false;
  ngOnInit(): void {
  }

  register(thePatient: Patient) {
    this.service.register(thePatient).subscribe(data => {
      console.log(data);
      this.registered = true;
     },
      (err) => console.log(err));
  }

  // newPatient(){
  //   this.registered = false;
  //   this.patient = {
  //     firstname: '',
  //     email: '',
  //     password: ''
  //   }
  // }

}
