import { Component, OnInit } from '@angular/core';
import { Patient } from '../Models/Patient';

@Component({
  selector: 'app-patient-login',
  templateUrl: './patient-login.component.html',
  styleUrls: ['./patient-login.component.css']
})
export class PatientLoginComponent implements OnInit {

  patient: Patient = {
    firstname: '',
    lastname: '',
    age : 0,
    mobileNo: 0,
    gender :'',
    pin :0,
    email: '',
    password: ''
  };

  constructor() { }

  ngOnInit(): void {
  }

  login(thePatient: Patient) {}

}
