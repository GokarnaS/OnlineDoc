import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard/dashboard.component';
import { PatientLoginComponent } from './patient-login/patient-login.component';
import { DoctorLoginComponent } from './doctor-login/doctor-login.component';
import { PatientRegisterComponent } from './patient-register/patient-register.component';


const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  { path: 'patientLogin', component: PatientLoginComponent },
  { path: 'doctorLogin', component: DoctorLoginComponent },
  { path: 'patientRegister', component: PatientRegisterComponent },
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
