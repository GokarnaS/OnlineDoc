
//const Patient = require('../models/patient.model');
 const db = require("../models");
 const Patient = db.patient;
//const Op = db.Sequelize.Op;

exports.create = function(req, res) {
    const new_patient =  {
      firstname: req.body.firstname,
      email: req.body.email,
      password: req.body.password
    };

  
      Patient.create(new_patient)
      .then(data => {
        res.send(data);
        console.log(data);
      })
      .catch(err => {
        res.status(500).send({
          message:
            err.message || "Some error occurred while creating the PAtient."
        });
      });

    
    };
