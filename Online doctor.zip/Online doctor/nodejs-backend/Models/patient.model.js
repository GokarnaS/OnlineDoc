module.exports = (sequelize, Sequelize) => {
  const Patient = sequelize.define("patient", {
    firstname: {
      type: Sequelize.STRING
    },
    email: {
      type: Sequelize.STRING
    },
    password: {
      type: Sequelize.STRING
    }
  },
  {freezeTableName:true,  timestamps: false});

  return Patient;
};


// 'use strict';
// var dbConn = require('../lib/db.js');

// //Employee object create
// var Patient = function(patient){
//   this.firstname     = patient.firstname;
//   this.password      = patient.password;
//   this.email          = patient.email;
// };

// Patient.create = function (newPatient, result) {
//     dbConn.query("INSERT INTO patient set ?", newPatient, function (err, res) {
//     if(err) {
//       console.log("error: ", err);
//       result(err, null);
//     }
//     else{
//       console.log(res.insertId);
//       result(null, res.insertId);
//     }
//     });
//     };

//     module.exports= Patient;