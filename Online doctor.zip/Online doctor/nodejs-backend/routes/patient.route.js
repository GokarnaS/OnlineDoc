const express = require('express')
const router = express.Router()
const patientController =   require('../controllers/patient.controller');


// Create a new patient
router.post('/', patientController.create);


module.exports = router